package sql_server

import "time"

const KDefaultTimeout = 30 * time.Second
