﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eShopSolution.WebApp.Models
{
    public class AddCartItemViewModel
    {
        public int Id { get; set; }

        public string LanguageId { get; set; }
    }
}