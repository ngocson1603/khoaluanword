﻿using System;
using System.Collections.Generic;
using System.Text;

namespace eShopSolution.ApiIntegration
{
    class OrderApiClient
    {
    }
}
