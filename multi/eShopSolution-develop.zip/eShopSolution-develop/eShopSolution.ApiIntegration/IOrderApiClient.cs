﻿using System;
using System.Collections.Generic;
using System.Text;

namespace eShopSolution.ApiIntegration
{
    public interface IOrderApiClient
    {
    }
}