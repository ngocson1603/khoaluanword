﻿using System;
using System.Collections.Generic;
using System.Text;

namespace eShopSolution.ViewModels.System.Products
{
    public class ProductDeleteRequest
    {
        public int Id { get; set; }
    }
}