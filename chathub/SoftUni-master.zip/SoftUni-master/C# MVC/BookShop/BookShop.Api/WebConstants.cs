﻿namespace BookShop.Api
{
    public class WebConstants
    {
        public const string WithId = "{id}";
    }
}
