﻿using Microsoft.AspNetCore.Mvc;

namespace BookShop.Api.Controllers
{
    [Route("api/[controller]")]
    public class BaseController : Controller
    {
    }
}
