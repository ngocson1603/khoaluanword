﻿namespace BookShop.Commons.Mapping
{
    public interface IMapFrom<TModel>
    {

    }
}
