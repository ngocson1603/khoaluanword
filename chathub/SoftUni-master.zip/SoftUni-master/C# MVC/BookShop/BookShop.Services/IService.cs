﻿namespace BookShop.Services
{
    public interface IService
    {
    }
}
