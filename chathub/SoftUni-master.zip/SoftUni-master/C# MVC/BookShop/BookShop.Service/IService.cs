﻿namespace BookShop.Service
{
    public interface IService
    {
    }
}
