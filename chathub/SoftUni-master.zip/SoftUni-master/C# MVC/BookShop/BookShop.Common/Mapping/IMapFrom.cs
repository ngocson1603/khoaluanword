﻿namespace BookShop.Common.Mapping
{
    public interface IMapFrom<TModel>
    {

    }
}
