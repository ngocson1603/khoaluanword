﻿namespace CameraBazaar.Data.Models
{
    public enum MakeType
    {
        Canon = 0,
        Nikon = 1,
        Penta = 2,
        Sony = 3
    }
}
