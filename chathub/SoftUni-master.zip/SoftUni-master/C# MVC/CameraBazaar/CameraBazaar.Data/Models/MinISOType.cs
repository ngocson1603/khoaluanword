﻿namespace CameraBazaar.Data.Models
{
    public enum MinISOType
    {
        ISO_50 = 50,
        ISO_100 = 100
    }
}
