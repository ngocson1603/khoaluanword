﻿namespace CameraBazaar.App.Infrastructure
{
    public static class GlobalConstants
    {
        public const string AdministratorRole = "Administrator";
    }
}
