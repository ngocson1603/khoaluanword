﻿namespace CameraBazaar.App.Infrastructure.Mapping
{
    interface IMapFrom<TModel>
    {
    }
}
