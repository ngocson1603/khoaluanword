﻿namespace CameraBazaar.App.Infrastructure.Mapping
{
    public interface IHaveCustomMappings
    {
        void ConfigureMapping(AutoMapperProfile profile);
    }
}
