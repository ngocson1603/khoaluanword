﻿namespace CameraBazaar.App.Models.Identity
{
    public class DeleteUserViewModel
    {
        public string Id { get; set; }

        public string Email { get; set; }
    }
}
