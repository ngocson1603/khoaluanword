﻿namespace _09.Crossfire
{
    using System;
    using System.Collections.Generic;

    public class Startup
    {
        static void Main()
        {

        }
    }
}
