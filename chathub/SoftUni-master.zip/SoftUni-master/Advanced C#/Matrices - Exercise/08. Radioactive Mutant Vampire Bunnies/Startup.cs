﻿namespace _08.Radioactive_Mutant_Vampire_Bunnies
{
    using System;
    using System.Collections.Generic;

    public class Startup
    {
        static void Main()
        {

        }
    }
}
