﻿namespace _11.Parking_System
{
    using System;
    using System.Collections.Generic;

    public class Startup
    {
        static void Main()
        {

        }
    }
}
