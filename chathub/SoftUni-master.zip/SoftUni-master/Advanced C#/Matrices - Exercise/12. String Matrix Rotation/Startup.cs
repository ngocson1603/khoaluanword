﻿namespace _12.String_Matrix_Rotation
{
    using System;
    using System.Collections.Generic;

    public class Startup
    {
        static void Main()
        {

        }
    }
}
