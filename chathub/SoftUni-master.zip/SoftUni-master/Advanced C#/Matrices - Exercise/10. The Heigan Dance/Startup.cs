﻿namespace _10.The_Heigan_Dance
{
    using System;
    using System.Collections.Generic;

    public class Startup
    {
        static void Main()
        {

        }
    }
}
