# chat_with_signalr
Chat with Signalr mvc 5

Tạo project với >net Frameword mvc 5
Cài đặt signalr: 
Cài qua nuget manager: Microsoft.AspNet,Signalr
Cài qua nuget console: Install-package Microsoft.AspNet,Signalr
