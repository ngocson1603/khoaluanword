namespace ChatApp.Models
{
    public enum UserRole
    {
        Admin,
        Member,
        Guest
    }
}