namespace ChatApp.Models
{
    public enum ChatType
    {
        Room,
        Private
    }
}