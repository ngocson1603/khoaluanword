-- SQLite
INSERT INTO User (user_id, email_address, password, source, first_name, last_name, profile_picture_url, date_of_birth, about_me, notifications, dark_theme, created_date, profile_pic_data_url)
VALUES (30,"maureen.cook@gmail.com","","APPL","Maureen","Cook","","12/2/1981","","","","","");