using System;
using System.Collections.Generic;
using System.Text;

namespace BlazingChat.Shared.ViewModels
{
    public class ContactsViewModel
    {
        public List<ChatViewModel> ChatViewModelList { get; set; }
    }
}
