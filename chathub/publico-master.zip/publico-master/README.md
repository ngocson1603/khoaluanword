# Publico - Open Talk Community using SignalR
In this video, we will build a real-time chat application using signalR with the user identity. I will show you how to create a public chat application where users can sign up and chat publicly to other users like slack.

# Watch the tutorial here

[![SignalR Tutorial](https://i.ytimg.com/vi/RUZLIh4Vo20/hqdefault.jpg?sqp=-oaymwEZCNACELwBSFXyq4qpAwsIARUAAIhCGAFwAQ==&rs=AOn4CLDlpxuLfu65rZBGGIbEaagNG-cUZg)](https://youtu.be/RUZLIh4Vo20)
