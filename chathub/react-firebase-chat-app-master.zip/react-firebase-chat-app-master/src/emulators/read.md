Thư mục này để tạo ra server giả
của firebase dưới localhost
