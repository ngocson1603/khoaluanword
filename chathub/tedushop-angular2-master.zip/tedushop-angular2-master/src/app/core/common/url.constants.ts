export class UrlConstants{
    public static LOGIN = "/login";
    public static HOME = "/main/home/index";
}