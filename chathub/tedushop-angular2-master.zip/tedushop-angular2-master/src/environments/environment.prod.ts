export const environment = {
  production: true,
  BASE_API: 'http://tedushopapi.tedu.com.vn'

};
