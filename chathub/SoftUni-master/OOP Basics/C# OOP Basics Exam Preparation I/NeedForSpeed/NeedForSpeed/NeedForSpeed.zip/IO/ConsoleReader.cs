﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class ConsoleReader
{
    public string Readline()
    {
        return Console.ReadLine();
    }
}
