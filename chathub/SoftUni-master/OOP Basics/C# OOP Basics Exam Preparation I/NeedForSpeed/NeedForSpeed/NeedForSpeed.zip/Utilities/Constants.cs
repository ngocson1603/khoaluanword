﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public static class Constants
{
    public const string INPUT_TERMINATING_COMMAND = "Cops Are Here";
    public const int MAX_PERCENTAGE = 100;
    public const int PERFOROMANCE_CAR_HOREPOWER_INCREASE_PERCENTAGE = 50;
    public const int PERFORMANCE_CAR_SUSPENSION_DECREASE_PERCENTAGE = 25;
    public const int WINNERS_COUNT = 3;

}
