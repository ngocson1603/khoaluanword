﻿using System;
using System.Collections.Generic;

namespace PlanetHunters.Dto
{
    public class DiscoveryDTO
    {
        public DiscoveryDTO()
        {
            Stars = new List<StarDTO>();
            Planets = new List<PlanetDTO>();
            Pioneers = new List<AstronomerDTO>();
            Observers = new List<AstronomerDTO>();
        }

        public string DateMade { get; set; }

        public string Telescope { get; set; }

        public ICollection<StarDTO> Stars { get; set; }

        public ICollection<PlanetDTO> Planets { get; set; }

        public ICollection<AstronomerDTO> Pioneers { get; set; }

        public ICollection<AstronomerDTO> Observers { get; set; }

    }
}
