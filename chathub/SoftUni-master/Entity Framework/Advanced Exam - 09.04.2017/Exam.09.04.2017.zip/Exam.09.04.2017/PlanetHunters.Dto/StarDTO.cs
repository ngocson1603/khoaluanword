﻿namespace PlanetHunters.Dto
{
    public class StarDTO
    {
        public string Name { get; set; }

        public string Temperature { get; set; }

        public string StarSystem { get; set; }
    }
}
