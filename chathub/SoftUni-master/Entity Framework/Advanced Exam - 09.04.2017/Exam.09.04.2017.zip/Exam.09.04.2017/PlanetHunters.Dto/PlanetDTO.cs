﻿namespace PlanetHunters.Dto
{
    public class PlanetDTO
    {
        public string Name { get; set; }

        public string Mass { get; set; }

        public string StarSystem { get; set; }
    }
}
