﻿
namespace PlanetHunters.Data
{
    using Dto;
    using Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class QueryHelpers
    {

        public static void ImportAstronomers(ICollection<AstronomerDTO> astronomers)
        {
            using (var context = new PlanetHuntersContext())
            {
                foreach (var astronomer in astronomers)
                {
                    if (astronomer.FirstName == null || astronomer.LastName == null)
                    {
                        Console.WriteLine("Invalid data format.");
                        continue;
                    }

                    Astronomer astronomerEntity = new Astronomer()
                    {
                        FirstName = astronomer.FirstName,
                        LastName = astronomer.LastName
                    };

                    context.Astronomers.Add(astronomerEntity);
                    Console.WriteLine($"Successfully imported {nameof(astronomerEntity)} {astronomerEntity.FirstName}.");
                }

                context.SaveChanges();
            }
        }


        public static void ImportTelescopes(ICollection<TelescopeDTO> telescopes)
        {
            using (var context = new PlanetHuntersContext())
            {
                foreach (var telescope in telescopes)
                {
                    if (telescope.Name == null || telescope.Location == null)
                    {
                        Console.WriteLine("Invalid data format.");
                        continue;
                    }

                    Telescope telescopeEntity = new Telescope()
                    {
                        Name = telescope.Name,
                        Location = telescope.Location,
                    };

                    if (telescope.MirrorDiameter!=null && telescope.MirrorDiameter>0m)
                    {
                        telescopeEntity.MirrorDiameter = telescope.MirrorDiameter;
                    }

                    context.Telescopes.Add(telescopeEntity);
                    Console.WriteLine($"Successfully imported {nameof(telescopeEntity)} {telescopeEntity.Name}.");
                }

                context.SaveChanges();
            }
        }

        public static void ImportDiscoveries(object discoveries)
        {
            throw new NotImplementedException();
        }

        public static void ImportStars(List<StarDTO> stars)
        {
            using (var context = new PlanetHuntersContext())
            {
                foreach (var star in stars)
                {
                    if (star.Name == null || star.Temperature == null || star.StarSystem == null || int.Parse(star.Temperature)<2400)
                    {
                        Console.WriteLine("Invalid data format.");
                        continue;
                    }

                    if (!context.StarSystems.Any(s => s.Name == star.StarSystem))
                    {
                        StarSystem starSystemEntity = new StarSystem()
                        {
                            Name = star.StarSystem,
                        };
                        context.StarSystems.Add(starSystemEntity);
                    }

                    context.SaveChanges();

                    Star starEntity = new Star()
                    {
                        Name = star.Name,
                        Temperature = int.Parse(star.Temperature),
                        StarSystem = context.StarSystems.First(s => s.Name == star.StarSystem)
                    };

                    context.Stars.Add(starEntity);
                    Console.WriteLine($"Successfully imported {nameof(starEntity)} {starEntity.Name}.");
                }

                context.SaveChanges();
            }
        }

        public static void ImportPlanets(ICollection<PlanetDTO> planets)
        {
            using (var context = new PlanetHuntersContext())
            {
                foreach (var planet in planets)
                {
                    if (planet.Name == null || planet.Mass == null || planet.StarSystem == null || decimal.Parse(planet.Mass)<=0m)
                    {
                        Console.WriteLine("Invalid data format.");
                        continue;
                    }

                    if (!context.StarSystems.Any(s=>s.Name == planet.StarSystem))
                    {
                        StarSystem starSystemEntity = new StarSystem()
                        {
                            Name = planet.StarSystem,
                        };
                        context.StarSystems.Add(starSystemEntity);
                    }

                    context.SaveChanges();

                    Planet planetEntity = new Planet()
                    {
                        Name = planet.Name,
                        Mass = decimal.Parse(planet.Mass),
                        StarSystem = context.StarSystems.First(s=>s.Name == planet.StarSystem)
                    };

                    context.Planets.Add(planetEntity);
                    Console.WriteLine($"Successfully imported {nameof(planetEntity)} {planetEntity.Name}.");
                }

                context.SaveChanges();
            }
        }
    }
}
