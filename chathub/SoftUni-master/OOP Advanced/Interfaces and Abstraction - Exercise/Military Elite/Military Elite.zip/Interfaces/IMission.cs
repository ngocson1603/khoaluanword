﻿namespace Military_Elite
{
    public interface IMission
    { 
        string Name { get; }

        string State { get; }
    }
}