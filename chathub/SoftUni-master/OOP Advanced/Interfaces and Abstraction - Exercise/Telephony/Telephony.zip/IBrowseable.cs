﻿public interface IBrowseable
{
    string Browse(string site);
}
