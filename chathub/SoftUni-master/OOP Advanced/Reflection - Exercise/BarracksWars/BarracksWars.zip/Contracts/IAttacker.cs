﻿namespace _03BarracksWars.Contracts
{
    public interface IAttacker
    {
        int AttackDamage { get; }
    }
}
