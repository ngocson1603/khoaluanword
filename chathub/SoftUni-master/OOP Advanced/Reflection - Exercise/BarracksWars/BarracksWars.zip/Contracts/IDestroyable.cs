﻿namespace _03BarracksWars.Contracts
{
    public interface IDestroyable
    {
        int Health { get; set; }
    }
}
