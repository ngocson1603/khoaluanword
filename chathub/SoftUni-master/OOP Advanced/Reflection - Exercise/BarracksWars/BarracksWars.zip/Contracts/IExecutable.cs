﻿namespace _03BarracksWars.Contracts
{
    public interface IExecutable
    {
        string Execute();
    }
}
