﻿namespace _03BarracksWars.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
