﻿public enum TrafficSignal
{
    Red,
    Green,
    Yellow
}
