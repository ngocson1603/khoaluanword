package com.vaibhavmojidra.notificationdemo.SendNotificationPack;

public class MyResponse {
    public int success;

}
