# Send-Notification-from-one-user-to-another-using-Firebase
For any Query You can contact me on any social : [Click here to contact me](https://vaibhavmojidra.blogspot.com/2019/12/about.html)
[![Screenshot_2020-05-01-20-45-49-081_com android chrome](https://user-images.githubusercontent.com/51367686/80816882-fb6dab80-8bed-11ea-86dd-e721f143f083.jpg)](https://www.youtube.com/watch?v=7Xc_5cduL-Y)
  YouTube : [Send Notification from one user to another using Firebase](https://www.youtube.com/watch?v=7Xc_5cduL-Y)

Send Notification from one user to another using Firebase Cloud Messaging by retrofit library. 
