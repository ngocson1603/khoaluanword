//
//  Page.swift
//  audible
//
//  Created by Hai Vo L. on 1/2/18.
//  Copyright © 2018 Hai Vo L. All rights reserved.
//

import Foundation

struct Page {
    let title: String
    let message: String
    let imageName: String
}
